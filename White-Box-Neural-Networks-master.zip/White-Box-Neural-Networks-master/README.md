<div align="center">
  <img src="https://raw.githubusercontent.com/wiki/develask/White-Box-Neural-Networks/wbnn_logo.png"><br><br>
</div>

-----------------

# White Box Neural Networks

This tookit is the result of two Master thesis, and is still under development. For the moment standard multilayer neural networks have been developed, as well as networks with paralell connections and recurrent neural netoworks, LSTMs included.

Everything you need to work with WBNN can be found in the GitHub Wiki:

[![Documentation](https://img.shields.io/badge/api-reference-blue.svg)](https://github.com/develask/White-Box-Neural-Networks/wiki)

